# areniX Technologies Limited — Website & Business Platform Prompt Pack

**Purpose:** A complete, agent-ready specification for building the public-facing **areniX** corporate website and the private areniX business dashboard.

**Brand:** `areniX` (public identity); `areniX Technologies Limited` (legal company name).

## Confirmed creative direction

**YES:** the entire **marketing/public website**—not only its homepage—must combine original design principles inspired by these five references:

1. **Altreex** — https://altreex.webflow.io/
2. **Onart Studio / Voyage** — https://onart-studio.webflow.io/project/voyage
3. **Visione** — https://visione.webflow.io/
4. **Monoform** — https://monoform-template.webflow.io/
5. **Nexifye** — https://nexifye.webflow.io/

The **admin dashboard** is deliberately different: high-density, accessible, fast operational UI that uses matching branding, **not** a cinematic editorial layout that impedes day-to-day use.

## Files and recommended reading order

| File | What it contains |
|---|---|
| `00_MASTER_BUILD_PROMPT.md` | Primary instruction to give a coding agent; requirements, scope, boundaries, workflow |
| `01_BRAND_DESIGN_AND_MOTION.md` | Five-reference synthesis, design tokens, page/scroll/hover motion rules |
| `02_PUBLIC_WEBSITE_PAGES.md` | Complete public sitemap; required sections and motion for each route |
| `03_PORTFOLIO_CASE_STUDIES.md` | All known projects, authentic screenshots, galleries, case studies, live-site links |
| `04_BOOKINGS_CRM_AND_ADMIN.md` | WhatsApp, consultation scheduling, inquiries, CRM, admin modules, notifications |
| `05_TECH_ARCHITECTURE_AND_SECURITY.md` | Next.js architecture, backend boundaries, data model, roles, performance/security |
| `06_BUILD_PLAN_AND_ACCEPTANCE.md` | Phase-by-phase implementation instructions, test matrix, evidence, sign-off |
| `07_CONTENT_ASSETS_AND_CONFIGURATION.md` | Real asset/input checklist, website links, status and copyright/data rules |
| `99_ALL_IN_ONE_BUILD_PROMPT.md` | **Self-contained** consolidated prompt; paste this single document when working without multi-file context |

## How to use

**If the AI coding tool can read multiple repository files:** place all `.md` files in a project docs folder, then instruct it to read `00_MASTER_BUILD_PROMPT.md` plus every numbered specification and implement in phases.

**If pasting one prompt into a coding tool:** paste `99_ALL_IN_ONE_BUILD_PROMPT.md`. This includes the master prompt and all supporting specifications.

**Execution rule:** Do not skip research, don't invent company facts or project capabilities, don't present private apps as publicly live, don't claim successful bookings/forms without actual backend confirmation, and don't use fake project screenshots.

**Project links presently provided or known:**
- Passion Nutrition Clinic: https://passion-nutrition-clinic.vercel.app/
- CleNest: https://www.clenest.site
- All other deployment/repository URLs must be obtained from approved project materials before publication.

**Important:** This is a build specification, **not** a claim that the website has already been coded, or that third-party integrations are currently configured. Animation requirements specify the intended areniX implementation; not all effects have been independently confirmed on every reference template.

# Phased Build Plan, QA Checklist, and Final Acceptance

## Delivery method

Build in vertical slices that **work end-to-end**, not thousands of lines of attractive placeholders. Review existing repo before editing. Make design and implementation decisions explicit. Keep every link/animation functional at its phase checkpoint. Avoid unnecessary assistant subagents; a single sequential coding agent can use these phases as a task list.

## Phase 0 — Discovery and constraints

- Inspect existing project files, package versions, assets and hosting constraints.
- Research all five specified Webflow reference sites; document observed elements vs areniX-inspired proposed effects.
- Confirm official company logo, brand color, domain, email, WhatsApp and permissioned screenshots where available; otherwise use clearly configurable pending state.
- Record known live links (Passion Nutrition Clinic, CleNest) and verify reachability when internet tools exist.
- Build an asset inventory and permission matrix for Paylio, netHuk and other portfolios.
- Write full route inventory, design-reference audit, motion matrix, content model, risk list.

**Gate:** reference audit, route list and asset inventory exist.

## Phase 1 — Shared frontend foundation

- Set up Next.js strict TypeScript, Tailwind v4, component primitives, typography, design tokens and animation utilities.
- Build responsive marketing shell, accessible nav, mobile menu, CTA buttons, branded footer and legal/system page wrappers.
- Motion infrastructure: GSAP/ScrollTrigger isolation + cleanup, React component transitions, reduced-motion fallback.
- Establish typed CMS/project fixture data and reusable URL/CTA helpers.

**Gate:** core shell works on 320–1920px and basic a11y; no broken routes or animation leakage.

## Phase 2 — Cinematic marketing UI

- Build Home with all described sections and original five-reference synthesis.
- Complete About, Services + service details, Solutions + details, Technologies, Process, Insights, Innovation Lab and Careers.
- Each route has editorial hierarchy, page-specific section motion, responsive fallback and working CTAs.
- Render only substantiated claims or obvious development placeholders.

**Gate:** all public routes have coherent real content states, navigation, responsive visual QA and accessible motion.

## Phase 3 — Authentic portfolio and case studies

- Implement searchable/filterable work grid and status indicators.
- Create seeded entries for eight initial known portfolio projects.
- Capture approved genuine website screenshots or provide clearly marked pending media; never fabricate.
- Add internal case-study pages, full-width gallery, image captions, verified technologies, project status and exact external URLs.
- Support CMS project update/media upload/preview order and publication status.

**Gate:** every public project has working `View Case Study`; only approved/live projects have `Visit Website`; screenshots are authentic/approved.

## Phase 4 — Visitor conversion workflows

- Configure true WhatsApp link (official areniX number), validated context text and accessible placement.
- Implement persisted contact and project inquiry forms with reference ID and staff email notification.
- Integrate consultation booking with real provider or honest request-only fallback.
- Test errors, duplicate submissions, timezone display, webhook verification, email outages.

**Gate:** site-submitted inquiry persists, staff sees it and receives real notification or queued notification; booking behavior matches actual availability state.

## Phase 5 — Protected operations dashboard

- Secure invitation-only authentication and RBAC.
- Live overview analytics and inquiry queue.
- CRM leads, client records, statuses, assignments and follow-ups.
- Booking management/calendar with sync and statuses.
- Proposal workflow + internal projects and audit history.
- CMS manager for portfolio/screenshots, services, blog, FAQs, careers, contact settings.
- Responsive admin UI with accessible tables, filters, forms, confirmation dialogs and operational empty states.

**Gate:** admin functions connected to real DB; unauthorized users cannot read/write sensitive records.

## Phase 6 — Harden and deploy

- Complete unit/integration/E2E tests.
- Test email/webhook failures, security boundaries, admin role changes and data leak prevention.
- Optimize critical imagery/animations, accessibility and SEO.
- Run production build, type checking, lint, DB migration and smoke tests.
- Produce environment/setup, deployment guide, admin manual, content maintenance and known blockers.

**Gate:** clear QA evidence; no known P0/P1 defects; production site behavior not simulated.

## Manual test matrix

| Test | Expected result |
|---|---|
| Home at 320px | No overflow, readable hero, usable CTAs, safe mobile animation |
| Home at desktop | Strong editorial/animated presentation with fast navigation |
| Mobile menu | Focusable links; opens/closes; Escape and route changes work |
| All public routes | Correct navigation, sections, CTA destinations, SEO metadata |
| Services detail | Distinct service content + contextual booking/contact path |
| Work filters | Correct filtered content with accessible live updates |
| Portfolio image/title | Opens correct `/work/[slug]` |
| `View Case Study` | Internal route works, back/breadcrumb works |
| `Visit Website` | Only visible with real public URL; new tab safe attributes |
| Screenshot gallery | Authentic correct project images, captions, keyboard/touch controls |
| Private Paylio / netHuk | No private data and no invented public link or false finished status |
| WhatsApp button | Opens official configured areniX chat with correct prefilled context |
| Contact submission | Validated, persisted, reference produced; actual email dispatch tracked |
| Project request | Context prefilled, attachments safe, DB record and admin alert |
| Consultation booking | Real available slot provider-confirmed OR explicit request-only fallback |
| Admin login | Invitation-only, secure session and role limits |
| Lead state update | Persists, visible in dashboard, auditable |
| Proposal | Versions/statuses correct; no unauthorized sending |
| CMS publish/unpublish | Public content changes safely, no leaks |
| Broken third-party service | Error explanation and safe recovery, no fake success |
| Reduced motion | All content readable, no scroll traps, minimal motion |
| Keyboard-only | Menu, form, filters, galleries, dialogs navigable |
| SEO | Unique titles, canonical routes, sitemap, correct index/noindex |
| Production build | Typecheck/lint/build pass or explicit honest failure report |

## Reporting template for each phase

```markdown
## Phase N — [name]
**Completed routes/components:** ...
**Working interactions verified:** ...
**Motion and responsive checks:** ...
**Backend integration status:** live / staging / stubbed / unconfigured
**Tests run and results:** ...
**Known issues (severity):** ...
**Files changed:** ...
**Next phase prerequisites:** ...
```

Do not claim “complete” based on visual inspection alone. Run the applications and tests as available; document exactly what was checked.

## Final acceptance — must all be true

1. All five reference influences have been intentionally synthesized into the **public marketing** experience, without copying assets/layouts wholesale.
2. Not only Home: every required route has appropriate visual and animation treatment.
3. All portfolio cards show authentic project media where approved/available, or honestly labeled pending illustrative states.
4. Each portfolio project has a working internal case study; public live links are genuine and conditional.
5. Contact/quote requests persist with correct confirmation and staff handling.
6. WhatsApp opens the correct company account; click-to-chat isn't falsely claimed as CRM sync.
7. Booking offers genuine slot confirmation or honest request-only fallback.
8. Admin CRM, leads, dashboard, bookings, CMS and role security work with real records.
9. 320px mobile through large desktop views are usable; reduced-motion and a11y paths work.
10. No confidential Paylio or other client data is exposed.
11. Production build works, and documented setup includes environment template/migrations.
12. Admin can update project thumbnails, gallery and URLs without changing code.
13. Any unbuilt later-phase feature (e.g., client portal, WhatsApp API) is distinctly marked future scope.

## Out-of-scope until specifically approved

- Auto-replying to WhatsApp or reading its messages (needs official Business Platform integration).
- Automatic payment collection or public service fee display (needs verified commercial terms and gateway integration).
- Fully featured private client portal; only architecture prepared initially.
- Invented business metrics, brand awards, customer testimonials or private project source access.
